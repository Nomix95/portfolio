'use client';

import { portfolioData } from '@/lib/data';
import { GitBranch, Mail, ExternalLink } from 'lucide-react';

export default function HeroSection() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left Column */}
          <div className="space-y-8">
            <div className="space-y-3">
              <div className="inline-block px-4 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                {portfolioData.subtitle}
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
                {portfolioData.name}
              </h1>
              <p className="text-xl text-gray-600">{portfolioData.title}</p>
            </div>

            <p className="text-lg text-gray-700 leading-relaxed max-w-xl">
              {portfolioData.tagline}
            </p>

            <p className="text-sm text-gray-600">{portfolioData.availability}</p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href={`mailto:${portfolioData.email}`}
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all hover:scale-105 font-medium"
              >
                <Mail size={20} />
                Get in Touch
              </a>
              <a
                href={portfolioData.github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all font-medium"
              >
                <GitBranch size={20} />
                GitHub
              </a>
            </div>

            {/* Contact Info */}
            <div className="space-y-2 pt-4">
              <div className="flex items-center gap-2 text-gray-700">
                <span className="text-blue-600">📍</span>
                {portfolioData.location}
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <span className="text-blue-600">📱</span>
                {portfolioData.phone}
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <span className="text-blue-600">✉️</span>
                {portfolioData.email}
              </div>
            </div>
          </div>

          {/* Right Column - Profile Card */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-2xl blur-3xl opacity-20 -z-10"></div>
            <div className="bg-white rounded-2xl p-8 shadow-2xl border border-gray-100">
              <div className="space-y-6">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto">
                  <span className="text-4xl font-bold text-white">NA</span>
                </div>

                <div className="text-center space-y-3">
                  <h2 className="text-2xl font-bold text-gray-900">{portfolioData.name}</h2>
                  <p className="text-blue-600 font-semibold">{portfolioData.title}</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600">
                      <strong>Status:</strong> 6th Semester BSCS Student at UET Gujranwala
                    </p>
                    <p className="text-sm text-gray-600 mt-2">
                      <strong>CGPA:</strong> 3.49 / 4.00
                    </p>
                  </div>

                  <div className="flex justify-center gap-4">
                    <a
                      href={portfolioData.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bg-gray-100 rounded-lg hover:bg-blue-100 transition-colors"
                      title="GitHub"
                    >
                      <GitBranch size={20} className="text-gray-700 hover:text-blue-600" />
                    </a>
                    <a
                      href={`mailto:${portfolioData.email}`}
                      className="p-3 bg-gray-100 rounded-lg hover:bg-blue-100 transition-colors"
                      title="Email"
                    >
                      <Mail size={20} className="text-gray-700 hover:text-blue-600" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
