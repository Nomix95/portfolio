'use client';

import { portfolioData } from '@/lib/data';

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Technical Skills</h2>
          <p className="text-lg text-gray-600">
            Comprehensive expertise across modern tech stack and emerging technologies.
          </p>
        </div>

        {/* Technical Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {portfolioData.skills.technical.map((skillGroup, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-6 border border-gray-200 hover:border-blue-400 transition-colors hover:shadow-lg"
            >
              <h3 className="text-lg font-bold text-gray-900 mb-4 text-blue-600">
                {skillGroup.category}
              </h3>
              <ul className="space-y-2">
                {skillGroup.items.map((skill, idx) => (
                  <li key={idx} className="text-gray-700 flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Design & Content Skills */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-16">
          {/* Design Skills */}
          <div className="bg-white rounded-lg p-8 border border-gray-200 hover:border-blue-400 transition-colors hover:shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-blue-600">
              Design & Content
            </h3>
            <div className="flex flex-wrap gap-3">
              {portfolioData.skills.design.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 text-gray-700 rounded-lg text-sm font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div className="bg-white rounded-lg p-8 border border-gray-200 hover:border-blue-400 transition-colors hover:shadow-lg">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-blue-600">
              Soft Skills
            </h3>
            <div className="flex flex-wrap gap-3">
              {portfolioData.skills.soft.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-4 py-2 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 text-gray-700 rounded-lg text-sm font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Languages */}
        <div className="bg-white rounded-lg p-8 border border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 mb-6 text-blue-600">
            Languages
          </h3>
          <div className="space-y-4">
            {portfolioData.skills.languages.map((lang, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <span className="text-gray-700 font-medium">{lang.language}</span>
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                  {lang.level}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
