'use client';

import { portfolioData } from '@/lib/data';
import { GitBranch, ExternalLink, ArrowRight } from 'lucide-react';

export default function ProjectsSection() {
  const featuredProjects = portfolioData.projects.filter(p => p.featured);
  const otherProjects = portfolioData.projects.filter(p => !p.featured);

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Notable Projects</h2>
          <p className="text-lg text-gray-600 max-w-2xl">
            A selection of production-ready applications spanning AI/ML, full-stack web development, WordPress, and systems programming.
          </p>
        </div>

        {/* Featured Projects */}
        <div className="space-y-12 mb-16">
          {featuredProjects.map((project, index) => (
            <div
              key={project.id}
              className="group relative bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl overflow-hidden border border-gray-200 hover:border-blue-400 transition-all hover:shadow-xl"
            >
              <div className="p-8 lg:p-10">
                <div className="flex flex-col lg:flex-row justify-between lg:items-start gap-8">
                  {/* Content */}
                  <div className="flex-1 space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-2">
                          {project.name}
                        </h3>
                        <p className="text-gray-700 leading-relaxed mb-4">
                          {project.description}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {project.github !== '#' && (
                          <a
                            href={project.github}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 bg-white rounded-lg hover:bg-gray-100 transition-colors"
                            title="View GitHub"
                          >
                            <GitBranch size={20} className="text-gray-700" />
                          </a>
                        )}
                        {project.demo !== '#' && (
                          <a
                            href={project.demo}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 bg-white rounded-lg hover:bg-gray-100 transition-colors"
                            title="View Demo"
                          >
                            <ExternalLink size={20} className="text-gray-700" />
                          </a>
                        )}
                      </div>
                    </div>

                    {/* Highlights */}
                    <ul className="space-y-2">
                      {project.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex gap-3 text-gray-700">
                          <span className="text-blue-500 mt-1 flex-shrink-0">•</span>
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 pt-4">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Other Projects Grid */}
        {otherProjects.length > 0 && (
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-8">Other Projects</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {otherProjects.map((project) => (
                <div
                  key={project.id}
                  className="group bg-white rounded-lg border border-gray-200 p-6 hover:border-blue-400 hover:shadow-lg transition-all"
                >
                  <div className="flex justify-between items-start gap-4 mb-4">
                    <div>
                      <h4 className="text-lg font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                        {project.name}
                      </h4>
                      <p className="text-sm text-gray-600 mt-2">
                        {project.description}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {project.github !== '#' && (
                        <a
                          href={project.github}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 bg-gray-100 rounded hover:bg-gray-200 transition-colors"
                          title="View GitHub"
                        >
                          <GitBranch size={16} className="text-gray-700" />
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {project.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                    {project.tags.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                        +{project.tags.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
