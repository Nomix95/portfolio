'use client';

import { portfolioData } from '@/lib/data';
import { GitBranch, Mail, Phone, MapPin, ArrowUp } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Contact Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-4">Let's Connect</h2>
          <p className="text-gray-300 text-lg mb-8 max-w-2xl">
            I'm always open to new opportunities, collaborations, and interesting projects. Feel free to reach out!
          </p>

          {/* Contact Methods */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Email */}
            <a
              href={`mailto:${portfolioData.email}`}
              className="group bg-white/10 border border-white/20 rounded-lg p-6 hover:bg-white/20 hover:border-blue-400 transition-all"
            >
              <Mail className="w-8 h-8 text-blue-400 mb-3" />
              <p className="text-sm text-gray-400 mb-2">Email</p>
              <p className="font-semibold group-hover:text-blue-300 transition-colors break-all">
                {portfolioData.email}
              </p>
            </a>

            {/* Phone */}
            <a
              href={`tel:${portfolioData.phone}`}
              className="group bg-white/10 border border-white/20 rounded-lg p-6 hover:bg-white/20 hover:border-blue-400 transition-all"
            >
              <Phone className="w-8 h-8 text-blue-400 mb-3" />
              <p className="text-sm text-gray-400 mb-2">Phone</p>
              <p className="font-semibold group-hover:text-blue-300 transition-colors">
                {portfolioData.phone}
              </p>
            </a>

            {/* Location */}
            <div className="bg-white/10 border border-white/20 rounded-lg p-6">
              <MapPin className="w-8 h-8 text-blue-400 mb-3" />
              <p className="text-sm text-gray-400 mb-2">Location</p>
              <p className="font-semibold">
                {portfolioData.location}
              </p>
            </div>

            {/* GitHub */}
            <a
              href={portfolioData.github}
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white/10 border border-white/20 rounded-lg p-6 hover:bg-white/20 hover:border-blue-400 transition-all"
            >
              <GitBranch className="w-8 h-8 text-blue-400 mb-3" />
              <p className="text-sm text-gray-400 mb-2">GitHub</p>
              <p className="font-semibold group-hover:text-blue-300 transition-colors">
                Nomix95
              </p>
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4">
            <a
              href={`mailto:${portfolioData.email}`}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white rounded-lg font-medium transition-all hover:shadow-lg"
            >
              Send me an Email
            </a>
            <a
              href={portfolioData.github}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 border-2 border-white/30 text-white hover:bg-white/10 rounded-lg font-medium transition-all"
            >
              View on GitHub
            </a>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/20 my-12"></div>

        {/* Bottom Footer */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-gray-400">
            <p>© 2024 Nouman Arif. All rights reserved.</p>
            <p className="text-sm mt-1">Full-Stack Developer | AI Enthusiast | Open Source Contributor</p>
          </div>

          <button
            onClick={scrollToTop}
            className="p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors hover:shadow-lg"
            title="Scroll to top"
          >
            <ArrowUp size={20} />
          </button>
        </div>
      </div>
    </footer>
  );
}
