'use client';

import { portfolioData } from '@/lib/data';

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Professional Experience</h2>
          <p className="text-lg text-gray-600">
            Hands-on experience across web development, design, content creation, and recruitment operations.
          </p>
        </div>

        {/* Experience Timeline */}
        <div className="space-y-8">
          {portfolioData.experience.map((job, index) => (
            <div key={index} className="relative">
              {/* Timeline dot and line */}
              <div className="flex gap-8">
                <div className="flex flex-col items-center">
                  <div className="w-4 h-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full border-4 border-white shadow-lg"></div>
                  {index !== portfolioData.experience.length - 1 && (
                    <div className="w-1 h-20 bg-gradient-to-b from-blue-200 to-transparent mt-4"></div>
                  )}
                </div>

                {/* Content */}
                <div className="pb-8 flex-1">
                  <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-lg p-6 border border-gray-200 hover:border-blue-400 transition-colors hover:shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">
                          {job.role}
                        </h3>
                        <p className="text-blue-600 font-semibold mt-1">
                          {job.company} • {job.location}
                        </p>
                      </div>
                      <span className="text-sm text-gray-600 bg-white px-3 py-1 rounded-full whitespace-nowrap">
                        {job.period}
                      </span>
                    </div>

                    {/* Highlights */}
                    <ul className="space-y-3">
                      {job.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex gap-3 text-gray-700">
                          <span className="text-blue-500 mt-1 flex-shrink-0">→</span>
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Education Section */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-gray-900 mb-12">Education</h2>

          <div className="space-y-6">
            {portfolioData.education.map((edu, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-6 border border-gray-200 hover:border-blue-400 transition-colors hover:shadow-lg"
              >
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">
                      {edu.degree}
                    </h3>
                    <p className="text-blue-600 font-semibold mt-2">
                      {edu.institution}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full inline-block whitespace-nowrap">
                      {edu.period}
                    </p>
                  </div>
                </div>
                <p className="text-gray-700 mt-4">{edu.details}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
